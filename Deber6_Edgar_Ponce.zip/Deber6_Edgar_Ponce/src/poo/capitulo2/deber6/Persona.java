/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.capitulo2.deber6;

/**
 *
 * @author pc ponce
 */
public class Persona {

    private String nombre;
    private String apellido;
    private String cedula;
    private String provincia;
    private String estadoCivil;
    private String pasatiempoFavorito;

    public Persona(String nombre, String apellido, String cedula) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.cedula = cedula;
      //  this.estadoCivil = estadoCivil;
      //  this.pasatiempoFavorito =  pasatiempoFavorito;

    }

    public boolean esNombrePalindromo(String nombre) {
        nombre = nombre.toLowerCase();

        boolean palindromo = true;

        int inicio = 0;
        int fin = nombre.length() - 1;

        while (inicio < fin) {
            if (nombre.charAt(inicio) != nombre.charAt(fin)) {
                palindromo = false;
            }
            inicio++;
            fin--;
        }

        return palindromo;
    }

    public boolean esCedulaValida(String cedula) {
        boolean validez = false;
        int cantidad = cedula.length();

        int puesto1 = Integer.parseInt(cedula.substring(0, 1));
        int puesto2 = Integer.parseInt(cedula.substring(1, 2));
        int puesto3 = Integer.parseInt(cedula.substring(2, 3));
        int puesto4 = Integer.parseInt(cedula.substring(3, 4));
        int puesto5 = Integer.parseInt(cedula.substring(4, 5));
        int puesto6 = Integer.parseInt(cedula.substring(5, 6));
        int puesto7 = Integer.parseInt(cedula.substring(6, 7));
        int puesto8 = Integer.parseInt(cedula.substring(7, 8));
        int puesto9 = Integer.parseInt(cedula.substring(8, 9));
        int puesto10 = Integer.parseInt(cedula.substring(9, 10));

        int sumaPares = puesto2 + puesto4 + puesto6 + puesto8;

        puesto1 = 2 * puesto1;
        if (puesto1 > 9) {
            puesto1 = puesto1 - 9;
        }
        puesto3 = 2 * puesto3;
        if (puesto3 > 9) {
            puesto3 = puesto3 - 9;
        }
        puesto5 = 2 * puesto5;
        if (puesto5 > 9) {
            puesto5 = puesto5 - 9;
        }
        puesto7 = 2 * puesto7;
        if (puesto7 > 9) {
            puesto7 = puesto7 - 9;
        }
        puesto9 = 2 * puesto9;
        if (puesto9 > 9) {
            puesto9 = puesto9 - 9;
        }

        int sumaImpares = puesto1 + puesto3 + puesto5 + puesto7 + puesto9;

        int sumaTotal = sumaPares + sumaImpares;

        int modulo = sumaTotal % 10;

        int valorVerificador;

        if (modulo >= 1 && modulo <= 9) {
            valorVerificador = 10 - modulo;
        } else {
            valorVerificador = 0;
        }

        int parInicial = Integer.parseInt(cedula.substring(0, 2));

        if (cantidad == 10 && valorVerificador == puesto10 && ((parInicial >= 1 && parInicial <= 24) || parInicial == 30)) {
            validez = true;
        }

        return validez;
    }

    public String buscarProvinciaNatal(String cedula) {
        int parInicial = Integer.parseInt(cedula.substring(0, 2));

        switch (parInicial) {
            case 1:
                provincia = "Azuay";
                break;
            case 2:
                provincia = "Bolivar";
                break;
            case 3:
                provincia = "Cañar";
                break;
            case 4:
                provincia = "Carchi";
                break;
            case 5:
                provincia = "Cotopaxi";
                break;
            case 6:
                provincia = "Chimborazo";
                break;
            case 7:
                provincia = "El Oro";
                break;
            case 8:
                provincia = "Esmeraldas";
                break;
            case 9:
                provincia = "Guayas";
                break;
            case 10:
                provincia = "Imbabura";
                break;
            case 11:
                provincia = "Loja";
                break;
            case 12:
                provincia = "Los Ríos";
                break;
            case 13:
                provincia = "Manabí";
                break;
            case 14:
                provincia = "Morona Santiago";
                break;
            case 15:
                provincia = "Napo";
                break;
            case 16:
                provincia = "Pastaza";
                break;
            case 17:
                provincia = "Pichincha";
                break;
            case 18:
                provincia = "Tungurahua";
                break;
            case 19:
                provincia = "Zamora Chinchipe";
                break;
            case 20:
                provincia = "Galápagos";
                break;
            case 21:
                provincia = "Sucumbíos";
                break;
            case 22:
                provincia = "Orellana";
                break;
            case 23:
                provincia = "Santo Domingo de los Tsáchilas";
                break;
            case 24:
                provincia = "Santa Elena";
                break;
            case 30:
                provincia = "ecuatorianos en consulados del Ecuador en el exterior";
                break;
        }
        return provincia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    public String getPasatiempoFavorito() {
        return pasatiempoFavorito;
    }

    public void setPasatiempoFavorito(String pasatiempoFavorito) {
        this.pasatiempoFavorito = pasatiempoFavorito;
    }
    
    @Override
    public String toString() {
        return "La Persona posee los siguientes datos:" + "\nNombre: " + nombre + "\nApellido: " + apellido + "\nCédula: " + cedula + "\nProvincia: " + provincia + "\nEstado Civil: " + estadoCivil + "\nPasatiempo Favorito: " + pasatiempoFavorito;
    }

    

    
}
